import React from 'react';
export default function NotFound() {
    return <h1>Not Found</h1>;
}
