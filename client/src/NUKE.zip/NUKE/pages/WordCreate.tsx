import React from 'react';
import WordForm from '../components/Word/WordForm';

export default function WordCreate() {
    return <WordForm currentWord={null} />;
}
