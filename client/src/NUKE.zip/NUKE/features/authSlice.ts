import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';

const initialState = {
    value: 0,
};

export const login = createAsyncThunk(
    'auth/register',
    async (user, thunkAPI) => {}
);

export const authSlice = createSlice({
    name: 'auth',
    initialState,
    reducers: {},
});

export default authSlice.reducer;
