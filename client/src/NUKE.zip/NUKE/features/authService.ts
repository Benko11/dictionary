import axios from 'axios';
import UserLogin from '../interfaces/UserLogin';

export const login = async (userData: UserLogin) => {
    const response = await axios.post(
        'http://localhost:3000/users/login',
        userData
    );

    if (response.data) {
        localStorage.setItem('user', JSON.stringify(userData));
    }

    return response.data;
};
