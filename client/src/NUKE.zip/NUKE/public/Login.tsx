import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { Link } from 'react-router-dom';
import { login } from '../features/authService';
import UserLogin from '../NUKE/interfaces/UserLogin';

export default function Login() {
    const dispatch = useDispatch();
    const [formData, setFormData] = useState<UserLogin>({
        email: '',
        password: '',
    });

    const onAuthenticate = async (e: any) => {
        e.preventDefault();

        dispatch(
            await login({ email: formData.email, password: formData.password })
        );
    };

    const onChange = (e: any) => {
        setFormData((prev) => {
            return { ...prev, [e.target.id]: e.target.value };
        });
    };

    return (
        <div className="flex flex-col my-16 mx-8 lg:mx-24 justify-center items-center font-body box-border">
            <div className="w-full md:w-[40rem]">
                <h1 className="pb-4 font-bold text-2xl ">Login</h1>

                <form className="flex flex-col gap-4" onSubmit={onAuthenticate}>
                    <div className="flex flex-col gap-2">
                        <label htmlFor="email">E-mail</label>
                        <input
                            type="email"
                            id="email"
                            value={formData.email}
                            onChange={onChange}
                        />
                    </div>
                    <div className="flex flex-col gap-2 ">
                        <label htmlFor="password">Password</label>
                        <input
                            type="password"
                            id="password"
                            value={formData.password}
                            onChange={onChange}
                        />
                    </div>
                    <div className="flex items-center gap-5 mt-4">
                        <button
                            type="submit"
                            className=" bg-cyan-600 text-gray-100 px-6 py-3 rounded-sm hover:bg-cyan-700 "
                        >
                            Login
                        </button>
                        <Link
                            to="/register"
                            className="text-cyan-600 px-6 py-3 hover:text-cyan-800"
                        >
                            Register
                        </Link>
                    </div>
                </form>
            </div>
        </div>
    );
}
