export default interface UserLogin {
    email: string;
    password: string;
}