export default interface Word {
    name: string;
    tags: any[];
    meanings: any[];
    media: string[];
}
